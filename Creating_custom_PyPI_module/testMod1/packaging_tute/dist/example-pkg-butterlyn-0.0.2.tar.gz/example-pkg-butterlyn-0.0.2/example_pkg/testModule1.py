def add_num(x=1,y=2):
    return x + y

class MyClass1():
    c = 320
    def show(self):
        print("This is a class method")